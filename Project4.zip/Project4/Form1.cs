﻿/*
 * Jeff Koss
 * Date: 04/15/2023
 * Class: MS539 Programming Concepts
 * Professor: Jill Coddington
 * Assignment: Assignment 4
 * ETA: 2 hours
 */

//This assignment took me a few days due to some scheduling problems,
//the overall code took me 3 hours to write and test.



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace Project4
{

    public partial class Form1 : Form
    {
        string strBinary0;
        string strBinary1;
        string strBinary2;
        string strBinary3;
        string strBinary4;
        string strBinary5;
        string strBinary6;
        string strBinary7;
        string listBinary;
        public Form1()
        {
            InitializeComponent();
        }

        public void RandomBinary()
        {
            int[] binary;
            binary = new int[8];
        
            Random rand = new Random();
            rand.Next(2);

            for (int i = i = 0; i < 8; i++)
            {
                binary[i] = rand.Next(2);
            }
            strBinary0 = binary[0].ToString();
            strBinary1 = binary[1].ToString();
            strBinary2 = binary[2].ToString();
            strBinary3 = binary[3].ToString();
            strBinary4 = binary[4].ToString();
            strBinary5 = binary[5].ToString();
            strBinary6 = binary[6].ToString();
            strBinary7 = binary[7].ToString();
            textBox1.Text = strBinary0 + strBinary1 + strBinary2 + strBinary3 + strBinary4 + strBinary5 + strBinary6 + strBinary7;
            listBinary = textBox1.Text;
            listBox1.Items.Add(listBinary);
        }

        private void ConvertBinanry()
        {
            int convert = 0;


            if (strBinary0 == "1")
            {
                convert = convert + 128;
            }
            if (strBinary1 == "1")
            {
                convert = convert + 64;
            }
            if (strBinary2 == "1")
            {
                convert = convert + 32;
            }
            if (strBinary3 == "1")
            {
                convert = convert + 16;
            }
            if (strBinary4 == "1")
            {
                convert = convert + 8;
            }
            if (strBinary5 == "1")
            {
                convert = convert + 4;
            }
            if (strBinary6 == "1")
            {
                convert = convert + 2;
            }
            if (strBinary7 == "1")
            {
                convert = convert + 1;
            }
            else
            {
                convert = convert + 0;
            }
            string converter = convert.ToString();

            textBox2.Text = converter;
        }

        private void SaveInfo()
        {
            StreamWriter outputFile;
            outputFile = File.CreateText("binarylist.txt");
            outputFile.WriteLine(listBinary);
            outputFile.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RandomBinary();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ConvertBinanry();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveInfo();
        }
    }
    
}
